#!/bin/bash
set -euxo pipefail
cd /opt/bench
sudo apt-get update -qq
sudo apt-get install -y libnuma-dev libaio-dev uuid-dev meson nasm pkg-config
 git clone https://github.com/spdk/spdk.git spdk-probe-src
cd spdk-probe-src
git checkout d519b163cbc0e2f28c35d9bc86d610da368b032c
git submodule update --init dpdk isa-l isa-l-crypto
./configure --without-isal --without-crypto --without-uring --without-vhost --without-virtio --without-fio --disable-tests --disable-unit-tests
make -j12
