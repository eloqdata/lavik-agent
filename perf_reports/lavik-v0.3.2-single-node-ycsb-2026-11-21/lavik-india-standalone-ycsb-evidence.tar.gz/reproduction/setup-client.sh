#!/usr/bin/env bash
set -euo pipefail
export DEBIAN_FRONTEND=noninteractive
sudo apt-get update -qq
sudo apt-get install -qy --no-install-recommends openjdk-17-jdk-headless maven python3-venv redis-tools jq golang-go
commit=247a2d448ebceff11a570a622c49ece161a27ed3
base=/opt/lavik-bench
sudo install -d -o bench -g bench "$base"
cd "$base"
if [[ ! -d YCSB-$commit ]]; then
  curl -fsSL --retry 2 --max-time 120 "https://codeload.github.com/eloqdata/YCSB/tar.gz/$commit" -o "ycsb-$commit.tar.gz"
  tar -xzf "ycsb-$commit.tar.gz"
fi
cd "YCSB-$commit"
mvn -B --no-transfer-progress -pl site.ycsb:lavik-binding,site.ycsb:redis-binding -am -DskipTests package
mvn -B --no-transfer-progress -pl core dependency:copy-dependencies -DincludeScope=runtime
python3 -m venv "$base/probe-venv"
"$base/probe-venv/bin/pip" install --disable-pip-version-check 'redis==8.1.0'
