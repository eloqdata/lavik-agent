#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
config=../ssh_config
scp -F "$config" scripts/{ycsb-standalone.sh,ycsb-standalone-sweep.py,verify-standalone.py,bulk-hash-load.go,run-case.sh,tcp-probe.py} client:/opt/lavik-bench/
ssh -F "$config" client 'cd /opt/lavik-bench; go build -o bulk-hash-load bulk-hash-load.go; test -x probe-venv/bin/python; test -d YCSB-247a2d448ebceff11a570a622c49ece161a27ed3/lavik/target; test -d YCSB-247a2d448ebceff11a570a622c49ece161a27ed3/redis/target'
