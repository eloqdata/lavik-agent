#!/usr/bin/env bash
set -euo pipefail
test "$(hostname -s)" = bench-data-india
evidence=/opt/lavik-bench/v4-repro/evidence
device=$(ip -j route get 10.87.0.10 | jq -r '.[0].dev')
ip -j route get 10.87.0.10 > "$evidence/client-route.json"
sudo systemctl stop irqbalance.service 2>/dev/null || true
sudo systemctl set-property --runtime system.slice AllowedCPUs=14-15
sudo systemctl set-property --runtime user.slice AllowedCPUs=14-15
sudo systemctl set-property --runtime init.scope AllowedCPUs=14-15
echo c000 | sudo tee /sys/devices/virtual/workqueue/cpumask >/dev/null
sudo python3 - "$device" <<'PY' | tee "$evidence/nic-irqs.txt"
from pathlib import Path
import os
import re
import sys
iface = Path("/sys/class/net") / sys.argv[1]
candidates = [link.resolve() for link in iface.glob("lower_*")] + [iface.resolve()]
devices = {(netdev/"device").resolve() for netdev in candidates}
devices = {d for d in devices if re.fullmatch(r"[0-9a-f]{4}:[0-9a-f]{2}:[0-9a-f]{2}\.[0-7]",d.name)}
irq_lines = Path("/proc/interrupts").read_text().splitlines()
all_irqs = set()
for device in sorted(devices):
    irqs = {entry.name for entry in (device/"msi_irqs").glob("*") if entry.name.isdigit()}
    if not irqs:
        irqs = {line.split(":",1)[0].strip() for line in irq_lines if device.name in line}
    all_irqs.update(irqs)
print(f"NIC PCI identities: {sorted(d.name for d in devices)}, IRQs: {sorted(all_irqs,key=int)}")
for idx, irq in enumerate(sorted(all_irqs,key=int)):
    path = Path("/proc/irq",irq,"smp_affinity_list")
    try:
        path.write_text(f"{14+idx%2}\n")
        print(f"{irq} effective requested {path.read_text().strip()}")
    except OSError as error:
        print(f"{irq} affinity unavailable: {error}")
for stat in Path("/proc").glob("[0-9]*/task/[0-9]*/stat"):
    try:
        raw = stat.read_text()
        flags = int(raw[raw.rindex(")")+2:].split()[6])
        if not (flags & 0x04000000):
            os.sched_setaffinity(int(stat.parent.name), {14,15})
    except (OSError,ValueError,IndexError):
        continue
PY
