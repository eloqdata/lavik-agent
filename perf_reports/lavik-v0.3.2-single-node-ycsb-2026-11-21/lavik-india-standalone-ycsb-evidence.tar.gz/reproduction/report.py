import json
from pathlib import Path
import re
import sys
from statistics import mean

root = Path(sys.argv[1])
destination = Path(sys.argv[2])
small_only = "--80m-only" in sys.argv[3:]
base = root / "client/results-standalone"
cases = [("redis", 80_000_000), ("dragonfly", 80_000_000),
         ("lavik", 80_000_000)]
if not small_only:
    cases.append(("lavik", 1_000_000_000))

def read_json(file):
    return json.loads(file.read_text())

def raw_window(file):
    metrics = {}
    for line in file.read_text().splitlines():
        if line.startswith(("[OVERALL], ", "[READ], ", "[UPDATE], ")):
            category, name, value = line.split(", ", 2)
            metrics.setdefault(category[1:-1], {})[name] = float(value)
    assert set(metrics) == {"OVERALL", "READ", "UPDATE"}
    runtime = metrics["OVERALL"]["RunTime(ms)"]
    throughput = metrics["OVERALL"]["Throughput(ops/sec)"]
    result = {"qps": throughput, "runtime_ms": int(runtime)}
    count = 0
    for tag in ("READ", "UPDATE"):
        stats = metrics[tag]
        assert stats["Operations"] == stats["Return=OK"] > 0
        assert all(name == "Return=OK" or value == 0
                   for name, value in stats.items() if name.startswith("Return="))
        operation = tag.lower()
        result[operation + "_ok"] = int(stats["Return=OK"])
        result[operation + "_p999_us"] = int(stats["99.9PercentileLatency(us)"])
        count += stats["Return=OK"]
    assert abs(throughput - count / (runtime / 1000)) < 2
    assert 0.049 <= result["update_ok"] / count <= 0.051
    return result

def load_stages(directory, count):
    stages = []
    for path in directory.glob("load-*-*.log"):
        line = next(line for line in path.read_text().splitlines() if line.startswith("final "))
        values = dict(fragment.split("=", maxsplit=1) for fragment in line.split()[1:])
        values = {key: float(value) if key in {"elapsed_s", "average_ops_s"} else int(value)
                  for key, value in values.items()}
        assert values["end"] - values["start"] == values["ack"]
        stages.append(values)
    stages.sort(key=lambda stage: stage["start"])
    assert stages[0]["start"] == (80_000_000 if count == 1_000_000_000 else 0)
    assert stages[-1]["end"] == count
    assert all(first["end"] == second["start"] for first, second in zip(stages, stages[1:]))
    return stages

def disk_metric(file, metric):
    pattern = rf"^{metric}(?:\{{[^\n]*\}})? ([\d.eE+]+)$"
    readings = re.findall(pattern, file.read_text(), flags=re.MULTILINE)
    assert readings, (file, metric)
    return round(sum(map(float, readings)))

def collect_case(product, count):
    directory = base / product / str(count)
    assert (directory / "complete").is_file(), directory
    stages = load_stages(directory, count)
    before, after = [read_json(directory / f"{step}-test.json") for step in ("pre", "post")]
    for sample in (before, after):
        assert sample["records"] == count and sample["sample_bad_records"] == 0
        assert sample["role"] == "master" and sample["connected_replicas"] == 0
    first_verification = next(json.loads(line) for line in (directory / "runner.log").read_text().splitlines()
                              if line.startswith('{"time_utc": ') and '"sample_sha256"' in line)
    assert first_verification["records"] == count and first_verification["sample_bad_records"] == 0
    sweep = read_json(directory / "sweep/summary.json")
    assert sweep["status"] == "confirmed", sweep
    connections = sweep["selected_connections"]
    assert connections == 256
    runs = []
    for round_number in (1, 2, 3):
        window = f"{connections}-confirm-{round_number}"
        confirmation = next(value for value in sweep["confirmation_windows"] if value["window"] == window)
        assert confirmation["valid"] and confirmation["seconds"] == 60
        run_dir = directory / "sweep" / window
        for metric in ("READ", "UPDATE"):
            assert (run_dir / f"{metric}.hdr").stat().st_size > 0
        log = run_dir / "ycsb.log"
        binding = "LavikClient" if product == "lavik" else "RedisClient"
        command = log.read_text().splitlines()[0]
        assert f"-db site.ycsb.db.{binding}" in command
        assert "-p scanproportion=0" in command
        assert "-threads 256 " in command
        if product != "lavik":
            assert "-p redis.scanindex=none" in command
        values = raw_window(log)
        assert 60_000 <= values["runtime_ms"] < 63_000
        for name, value in values.items():
            assert value == confirmation[name], (window, name, value, confirmation[name])
        runs.append(values)
    for name in ("qps", "read_p999_us", "update_p999_us"):
        assert abs(mean(run[name] for run in runs) - sweep[name]) < 1e-5
    result = dict(product=product, records=count, raw_value_bytes=count * 8 * 128,
                  load=stages, before=before, after=after, initial_sample=first_verification,
                  idle_ping=read_json(directory / "idle-ping.json"),
                  connections=connections, qps=sweep["qps"], read_p999_us=sweep["read_p999_us"],
                  update_p999_us=sweep["update_p999_us"], confirmations=runs,
                  scouts=sweep["scout_windows"], stop_reason=sweep["stop_reason"])
    if product == "lavik":
        empty_metrics = base / "lavik/80000000/metrics-before-load.prom"
        before_metrics = directory / "metrics-before-test.prom"
        capacity = disk_metric(before_metrics, "lavik_storage_capacity_bytes")
        empty_available = disk_metric(empty_metrics, "lavik_storage_available_bytes")
        available = disk_metric(before_metrics, "lavik_storage_available_bytes")
        assert capacity >= empty_available > available
        pending = disk_metric(before_metrics, "lavik_storage_durability_pending")
        dirty_bytes = disk_metric(before_metrics, "lavik_storage_dirty_staging_bytes")
        if count == 1_000_000_000:
            assert pending == dirty_bytes == 0
        result.update(storage_capacity_bytes=capacity,
                      consumed_foreground_bytes_since_empty=empty_available - available,
                      durability_pending_before_test=pending,
                      dirty_staging_bytes_before_test=dirty_bytes)
    return result

results = [collect_case(*case) for case in cases]
assert len({row["initial_sample"]["sample_sha256"] for row in results if row["records"] == 80_000_000}) == 1
(root / "summary.json").write_text(json.dumps(results, indent=2) + "\n")
versions = {"redis": "Redis 8.10.3", "dragonfly": "Dragonfly v2.1", "lavik": "Lavik v0.3.2"}

def number(x):
    return f"{x:,.0f}"

def gib(x):
    return f"{x / 2**30:.1f}"

def ms(x):
    return f"{x / 1000:.3f}"

def table_row(row):
    return (f"| {versions[row['product']]} | {number(row['records'])} | "
            f"{row['connections']} | {number(row['qps'])} | {ms(row['read_p999_us'])} | "
            f"{ms(row['update_p999_us'])} | {gib(row['after']['used_memory_bytes'])} |")

labels = {80_000_000: "8,000 万条", 1_000_000_000: "10 亿条"}
scale_context = ""
scale_result = ""
if not small_only:
    small_lavik, large_lavik = results[-2:]
    disk_usage = large_lavik["consumed_foreground_bytes_since_empty"]
    load_seconds = sum(stage["elapsed_s"] for result in results[-2:] for stage in result["load"])
    scale_context = "Lavik 随后扩容到 10 亿条，仍用一台数据机服务。"
    scale_result = f"""Lavik 的数据量放大 12.5 倍后，达到 **{number(large_lavik['qps'])} ops/s**，为 8,000 万条测试吞吐的 **{large_lavik['qps'] / small_lavik['qps']:.1%}**。10 亿条的字段值合计 **1.024 TB**（十进制，1 TB = 10¹² B）。

10 亿条灌入后、正式压测前，Lavik 报告的可供前台写入空间较空库减少 **{disk_usage / 10**12:.3f} TB**。该值来自相同分区上两次 `lavik_storage_available_bytes` 的差值，包含引擎空间开销。此时引擎报告待持久化活动及脏暂存字节均为零。灌入全部 10 亿条的各阶段加总用时 **{load_seconds / 60:.1f} 分钟**。
"""
content = f"""# 单机 Hash YCSB 基准测试

在 Azure Central India 的同一台 16 vCPU 数据机上，Redis、Dragonfly 和 Lavik 各测试了 8,000 万条 Hash 记录。YCSB 在独立机器上发请求，统一使用 256 个连接。{scale_context}

| 数据库 | Hash 记录数 | 连接数 | 吞吐量（ops/s） | 读 P99.9（ms） | 写 P99.9（ms） | 测后数据库报告内存（GiB） |
|---|---:|---:|---:|---:|---:|---:|
""" + "\n".join(map(table_row, results)) + f"""

8,000 万条数据集的字段值合计 **81.92 GB**。

{scale_result}
## 环境与操作口径

- 机房为 Azure Central India Zone 3。数据机为 `Standard_L16aos_v4`，16 vCPU、128 GiB 标称内存、AMD EPYC 9V74。独立 YCSB 发压机为 `Standard_F16als_v6`，16 vCPU。两台机器均开启加速网络。数据机 14 个 CPU 分配给服务，其余两个分配给系统和网卡中断。 [Azure L16aos_v4 规格](https://learn.microsoft.com/en-us/azure/virtual-machines/sizes/storage-optimized/laosv4-series)
- 每个 Hash 有 8 个 128 B 字段。每轮访问范围为当轮完整数据集，均匀随机。95% 请求读取整个 Hash，5% 请求更新全部 8 个字段。Redis 和 Dragonfly 用 YCSB Redis binding，设置 `redis.scanindex=none`（`HGETALL` / `HMSET`），Lavik 用专用 binding（`HGETALL` / `LAVIK.HREPLACE`）。正式发压每线程一个连接，每连接串行发请求。灌数单独采用 64 连接、每批 32 请求的流水线。 [YCSB 源码](https://github.com/eloqdata/YCSB/commit/247a2d448ebceff11a570a622c49ece161a27ed3)
- 每次只运行一个数据库实例。Redis 和 Dragonfly 为纯内存，设 112 GiB 内存限制，关闭定期快照、淘汰及 Redis AOF。Lavik 使用 io_uring 和本地六盘 NVMe RAID0 的裸分区，内存上限设为 96 GiB。内存列沿用各引擎的 `INFO MEMORY used_memory` 定义，统计口径可能不同。 [Redis 8.10.3](https://github.com/redis/redis/releases/tag/8.10.3) · [Dragonfly v2.1](https://github.com/dragonflydb/dragonfly/releases/tag/v2.1) · [Lavik v0.3.2](https://github.com/eloqdata/lavik/releases/tag/v0.3.2)
- 正式窗口固定 256 连接，三轮各 60 秒。表中是三轮吞吐及各轮读写 P99.9 的算术平均。每组测试前后验证键数、独立服务状态，并抽查 1,003 条记录的字段名与字段长度。正式窗口的读写都返回成功。三款数据库初次装载的样本摘要一致。取样和容量证明见随报告附带的原始证据。

## 三轮正式结果

| 数据库 | 记录数 | 轮次 | 吞吐量（ops/s） | 读 P99.9（ms） | 写 P99.9（ms） |
|---|---|---:|---:|---:|---:|
"""
for row in results:
    name = versions[row["product"]]
    dataset = labels[row["records"]]
    for round_number, run in enumerate(row["confirmations"], start=1):
        content += (f"| {name} | {dataset} | {round_number} | {number(run['qps'])} | "
                    f"{ms(run['read_p999_us'])} | {ms(run['update_p999_us'])} |\n")

content += """
## 原始证据

同行的证据压缩包包含版本、机器与存储信息，灌数阶段日志、抽样校验、各窗口的 YCSB 日志与 HdrHistogram、Lavik 存储指标和复现实验脚本。此前的连接数探索试验单独留档。
"""
destination.write_text(content)
print(json.dumps([{"product": row["product"], "records": row["records"],
                   "connections": row["connections"], "qps": row["qps"],
                   "read_p999_us": row["read_p999_us"], "update_p999_us": row["update_p999_us"]}
                  for row in results], indent=2))
