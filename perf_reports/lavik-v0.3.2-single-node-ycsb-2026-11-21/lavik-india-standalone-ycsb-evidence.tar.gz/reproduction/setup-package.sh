#!/usr/bin/env bash
set -euo pipefail
base=/opt/lavik-bench
release=lavik-v0.3.2-linux-x86_64
url="https://github.com/eloqdata/lavik/releases/download/v0.3.2"
sudo install -d -o bench -g bench "$base"
cd "$base"
if [[ ! -x $release/lavik ]]; then
  curl -fsSLO --retry 2 --max-time 120 "$url/$release.tar.gz.sha256"
  curl -fsSLO --retry 2 --max-time 300 "$url/$release.tar.gz"
  sha256sum -c "$release.tar.gz.sha256"
  tar -xzf "$release.tar.gz"
fi
"$base/$release/lavik" --version
uname -r
