from socket import create_connection, TCP_NODELAY, IPPROTO_TCP
from time import perf_counter_ns
from statistics import quantiles, median
import argparse
import json

argument = argparse.ArgumentParser()
argument.add_argument("host")
argument.add_argument("port", type=int)
args = argument.parse_args()
durations = []
with create_connection((args.host,args.port),timeout=3) as conn:
    conn.setsockopt(IPPROTO_TCP,TCP_NODELAY,1)
    request=b"*1\r\n$4\r\nPING\r\n"
    with conn.makefile("rb") as replies:
        for index in range(5200):
            started=perf_counter_ns()
            conn.sendall(request)
            if replies.readline() != b"+PONG\r\n":
                raise RuntimeError("Expected PONG")
            if index >= 200:
                durations.append((perf_counter_ns()-started)/1000)
percentiles=quantiles(durations,n=100,method="inclusive")
print(json.dumps({"host":args.host,"port":args.port,"ops":len(durations),
                  "median_us":median(durations),"p95_us":percentiles[94],"p99_us":percentiles[98]}))
