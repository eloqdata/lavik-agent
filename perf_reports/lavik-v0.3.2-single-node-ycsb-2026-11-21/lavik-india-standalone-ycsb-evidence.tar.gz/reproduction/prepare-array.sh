#!/usr/bin/env bash
set -euo pipefail
test "$(hostname -s)" = bench-data-india
export DEBIAN_FRONTEND=noninteractive
sudo apt-get update -qq
sudo apt-get install -qy --no-install-recommends mdadm fio nvme-cli jq redis-tools libcurl4t64 libssl3t64 > /tmp/v4-package-install.log 2>&1
root=/opt/lavik-bench/v4-repro
sudo install -d -o bench -g bench "$root"
mkdir -p "$root/evidence"
cd "$root"
uname -a > evidence/uname.txt
lscpu > evidence/lscpu.txt
lsblk -b -J -o NAME,PATH,TYPE,SIZE,MODEL,SERIAL,FSTYPE,MOUNTPOINTS > evidence/disks.json
array=/dev/md/lavikbench
if [[ ! -b $array ]]; then
python3 - <<'PY' > evidence/approved-devices.txt
from pathlib import Path
import json
items=json.loads(Path("evidence/disks.json").read_text())["blockdevices"]
disks=[x for x in items if x["type"]=="disk" and x["name"].startswith("nvme")
       and 1.8*10**12 <= int(x["size"]) <= 2.0*10**12]
if len(disks)!=6:
    raise SystemExit("Expected exactly six dedicated 1.92 TB NVMe devices")
for d in disks:
    if d.get("children") or d["fstype"] or any(d["mountpoints"]):
        raise SystemExit(f"Dedicated test device {d['path']} is in use")
    print(d["path"])
PY
mapfile -t disks < evidence/approved-devices.txt
test "${#disks[@]}" = 6
test ! -e /dev/md/lavikbench
for disk in "${disks[@]}"; do
  signatures=$(sudo wipefs --no-act --noheadings --output TYPE "$disk")
  [[ -z $signatures ]]
done
sudo mdadm --create /dev/md/lavikbench -l 0 -n 6 --chunk=512 --metadata=1.2 "${disks[@]}"
sudo udevadm settle
test "$(sudo blockdev --getss "$array")" = 512
sudo mdadm --detail "$array" > evidence/raid.txt
python3 - <<'PY' > evidence/partitions.sfdisk
unit = 24 * 2**20 // 512
size = 1099494850560 // 512
second = (unit + size + unit-1)//unit * unit
print("label: gpt\nunit: sectors")
print(f'start={unit},size={size},type=linux,name="lavik-v4-ycsb"')
print(f'start={second},size={size},type=linux,name="reserved-v4-ycsb"')
PY
sudo sfdisk "$array" < evidence/partitions.sfdisk
sudo udevadm settle
fi
sudo mdadm --detail "$array" > evidence/raid.txt
test "$(awk '/Active Devices/{print $NF}' evidence/raid.txt)" = 6
test "$(awk '/Raid Level/{print $NF}' evidence/raid.txt)" = raid0
sudo sfdisk --json "$array" > evidence/partitions.json
for index in 1 2; do
  part=/dev/md/lavikbench"$index"
  if [[ $index == 1 ]]; then label=lavik-v4-ycsb; else label=reserved-v4-ycsb; fi
  test "$(lsblk -dn -o PARTLABEL "$part" | xargs)" = "$label"
  test "$(sudo blockdev --getsize64 "$part")" = 1099494850560
  sudo python3 - "$part" <<'PY'
import sys
with open(sys.argv[1], "rb", buffering=0) as stream:
    for start in (0,2**20,256*2**30,512*2**30,1000*2**30):
        stream.seek(start)
        if any(stream.read(16384)):
            raise SystemExit(f"nonzero sample at {start} in {sys.argv[1]}")
PY
done
