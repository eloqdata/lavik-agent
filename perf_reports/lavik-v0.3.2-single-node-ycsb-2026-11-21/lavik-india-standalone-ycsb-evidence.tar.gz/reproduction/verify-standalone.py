import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import random
from redis import Redis

parser = argparse.ArgumentParser()
parser.add_argument("output",type=Path)
parser.add_argument("records", type=int)
parser.add_argument("--expected-sample")
args = parser.parse_args()
def ycsb_key(number):
    value = 0xCBF29CE484222325
    for octet in number.to_bytes(8, "little"):
        value = ((value ^ octet) * 1099511628211) & ((1 << 64) - 1)
    if value >= (1 << 63):
        value -= 1 << 64
    return "user" + str(abs(value))

def sample_hashes(connection, keys):
    with connection.pipeline(transaction=False) as pipe:
        for key in keys:
            pipe.hgetall(key)
        values = pipe.execute()
    field_names = {f"field{i}".encode() for i in range(8)}
    bad_lengths = sum(fields.keys() != field_names or any(len(v) != 128 for v in fields.values())
                      for fields in values)
    digest = hashlib.sha256()
    for fields in values:
        for name, value in sorted(fields.items()):
            digest.update(name + b"\x00" + value)
    return digest.hexdigest(), bad_lengths


expected = args.records
rng = random.Random(326)
ordinals = [0, expected - 1, expected // 2] + rng.sample(range(expected), 1000)
connection = Redis(host="10.87.0.21", socket_timeout=10)
key_count = connection.dbsize()
sample, bad_lengths = sample_hashes(connection, [ycsb_key(n) for n in ordinals])
replication = connection.info("replication")
memory = connection.info("memory")
detail = {
    "time_utc": datetime.now(timezone.utc).isoformat(),
    "records": key_count, "role": replication["role"],
    "connected_replicas": replication.get("connected_slaves", 0),
    "full_replication_info": replication,
    "sample_sha256": sample, "sample_bad_records": bad_lengths,
    "used_memory_bytes": memory["used_memory"],
    "used_memory_rss_bytes": memory.get("used_memory_rss"),
    "maxmemory_bytes": memory.get("maxmemory"),
}
args.output.parent.mkdir(parents=True, exist_ok=True)
args.output.write_text(json.dumps(detail,indent=2) + "\n")
assert key_count == expected and bad_lengths == 0
assert detail["role"] == "master" and detail["connected_replicas"] == 0
assert not args.expected_sample or sample == args.expected_sample
print(json.dumps({k:v for k,v in detail.items() if k != "full_replication_info"}))
