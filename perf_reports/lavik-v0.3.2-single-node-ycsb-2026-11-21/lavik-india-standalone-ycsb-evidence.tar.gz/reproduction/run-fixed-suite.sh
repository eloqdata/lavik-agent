#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
config=../ssh_config
remote=/opt/lavik-bench
server=10.87.0.21

log() { printf '%s %s\n' "$(date -u +%FT%TZ)" "$*"; }
data() { ssh -F "$config" data "$@"; }
client() { ssh -F "$config" client "$@"; }

wait_database() {
  local expected=$1 count
  for attempt in {1..60}; do
    count=$(client "redis-cli -h '$server' DBSIZE" 2>/dev/null || true)
    if [[ $count = "$expected" ]]; then
      return
    fi
    sleep 5
  done
  log "Expected $expected records. Last reply $count"
  return 1
}

wait_case() {
  local unit=$1 product=$2 count=$3 state
  local output="$remote/results-standalone/$product/$count"
  while true; do
    state=$(client "systemctl show '$unit' --property=ActiveState --value" || true)
    case "$state" in
      active|activating|deactivating|'') sleep 15 ;;
      *)
        if client "test -f '$output/complete'"; then
          log "Completed $product $count"
          client "jq -c '{status,selected_connections,qps,read_p999_us,update_p999_us}' '$output/sweep/summary.json'"
          return
        fi
        client "tail -15 '$output/runner.log'" || true
        log "Stopped at $product $count with state $state"
        return 1 ;;
    esac
  done
}

launch_case() {
  local product=$1 count=$2 from=$3
  local unit="india-fixed-$product-$count"
  local output="$remote/results-standalone/$product/$count"
  log "Starting $product $count from $from, fixed 256 connections"
  wait_database "$from"
  client "sudo mkdir -p '$output'; sudo chown bench:bench '$output'; sudo systemd-run --unit=$unit --uid=bench --gid=bench -p WorkingDirectory=$remote -p 'StandardOutput=append:$output/runner.log' -p StandardError=inherit /bin/bash $remote/run-case.sh $product $count $from"
  wait_case "$unit" "$product" "$count"
}

mode=${1:-existing-lavik}
if [[ $mode = existing-lavik ]]; then
  wait_case india-case-lavik-80000000 lavik 80000000
elif [[ $mode != after-lavik ]]; then
  data "bash '$remote/prepare-current-storage.sh' && bash '$remote/manage-server.sh' start lavik"
  launch_case lavik 80000000 0
fi
if data "systemctl is-active --quiet india-single-lavik"; then
  data "bash '$remote/manage-server.sh' stop lavik"
fi
for product in redis dragonfly; do
  client "cd '$remote/results-standalone/$product' && { test ! -e 80000000 || sudo mv 80000000 80000000-exploratory; }"
  data "bash '$remote/manage-server.sh' start $product"
  launch_case "$product" 80000000 0
  data "bash '$remote/manage-server.sh' stop $product"
done
log 'Completed the three 80-million-record cases at 256 connections'
data "bash '$remote/manage-server.sh' start lavik"
wait_database 80000000
client "cd '$remote' && probe-venv/bin/python verify-standalone.py results-standalone/lavik/80000000/post-restart.json 80000000 --expected-sample \$(jq -r .sample_sha256 results-standalone/lavik/80000000/post-test.json)"
launch_case lavik 1000000000 80000000
log 'Completed all four standalone cases at 256 connections'
