package main

import (
	"bufio"
	"bytes"
	"context"
	"flag"
	"fmt"
	"math/rand/v2"
	"net"
	"os"
	"strconv"
	"sync"
	"sync/atomic"
	"time"
)

func recordKey(number int64) string {
	hash := uint64(0xCBF29CE484222325)
	for i := 0; i < 8; i++ {
		hash = (hash ^ uint64(byte(number))) * 1099511628211
		number >>= 8
	}
	key := int64(hash)
	if key < 0 {
		key = -key
	}
	return "user" + strconv.FormatInt(key, 10)
}

// Match the YCSB byte alphabet and field shape, with a per-connection PRNG.
func appendRecord(buffer []byte, number int64, random *rand.Rand) []byte {
	key := recordKey(number)
	buffer = append(buffer, "*18\r\n$5\r\nHMSET\r\n$"...)
	buffer = strconv.AppendInt(buffer, int64(len(key)), 10)
	buffer = append(buffer, "\r\n"...)
	buffer = append(buffer, key...)
	buffer = append(buffer, "\r\n"...)
	masks := [...]uint32{31, 63, 95, 31, 63, 95}
	shifts := [...]uint32{0, 5, 10, 15, 20, 25}
	for field := range 8 {
		buffer = append(buffer, "$6\r\nfield"...)
		buffer = append(buffer, byte('0'+field))
		buffer = append(buffer, "\r\n$128\r\n"...)
		for offset := 0; offset < 128; {
			bits := random.Uint32()
			for i := range min(128-offset, 6) {
				buffer = append(buffer, byte((bits>>shifts[i])&masks[i])+' ')
				offset++
			}
		}
		buffer = append(buffer, "\r\n"...)
	}
	return buffer
}

func runWorker(ctx context.Context, address string, start, end int64, depth int,
	acked *atomic.Int64) error {
	dialer := net.Dialer{Timeout: 10 * time.Second}
	connection, err := dialer.DialContext(ctx, "tcp", address)
	if err != nil {
		return err
	}
	defer connection.Close()
	reader := bufio.NewReaderSize(connection, 8*1024)
	buffer := make([]byte, 0, depth*1280)
	random := rand.New(rand.NewPCG(uint64(start), uint64(end)))
	for first := start; first < end; first += int64(depth) {
		if err := ctx.Err(); err != nil {
			return err
		}
		last := min(first+int64(depth), end)
		buffer = buffer[:0]
		for number := first; number < last; number++ {
			buffer = appendRecord(buffer, number, random)
		}
		if err := connection.SetDeadline(time.Now().Add(30 * time.Second)); err != nil {
			return err
		}
		if _, err := connection.Write(buffer); err != nil {
			return fmt.Errorf("write batch at ordinal %d: %w", first, err)
		}
		for number := first; number < last; number++ {
			reply, err := reader.ReadSlice('\n')
			if err == nil && !bytes.Equal(reply, []byte("+OK\r\n")) {
				err = fmt.Errorf("unexpected server reply %q", reply)
			}
			if err != nil {
				acked.Add(number - first)
				return fmt.Errorf("acknowledgement at ordinal %d: %w", number, err)
			}
		}
		acked.Add(last - first)
	}
	return nil
}

func main() {
	address := flag.String("address", "10.87.0.21:6379", "primary address")
	start := flag.Int64("start", 0, "first YCSB key ordinal")
	end := flag.Int64("end", 0, "exclusive ending ordinal")
	connections := flag.Int("connections", 64, "TCP connections")
	pipeline := flag.Int("pipeline", 32, "requests per batch per connection")
	flag.Parse()
	if *start < 0 || *end <= *start || *connections <= 0 || *pipeline <= 0 {
		fmt.Fprintln(os.Stderr, "invalid range, connection count, or pipeline depth")
		os.Exit(2)
	}
	ctx, cancel := context.WithCancelCause(context.Background())
	defer cancel(nil)
	started := time.Now()
	count := *end - *start
	var acknowledged atomic.Int64
	var workers sync.WaitGroup
	for worker := range *connections {
		from := *start + count*int64(worker)/int64(*connections)
		to := *start + count*int64(worker+1)/int64(*connections)
		workers.Add(1)
		go func() {
			defer workers.Done()
			if err := runWorker(ctx, *address, from, to, *pipeline, &acknowledged); err != nil {
				cancel(err)
			}
		}()
	}
	finished := make(chan struct{})
	go func() {
		workers.Wait()
		close(finished)
	}()
	report := func(kind string) {
		seconds := time.Since(started).Seconds()
		operations := acknowledged.Load()
		fmt.Printf("%s start=%d end=%d elapsed_s=%.3f ack=%d average_ops_s=%.1f\n",
			kind, *start, *end, seconds, operations, float64(operations)/seconds)
	}
	ticker := time.NewTicker(10 * time.Second)
	defer ticker.Stop()
	for {
		select {
		case <-ticker.C:
			report("progress")
		case <-finished:
			report("final")
			if err := context.Cause(ctx); err != nil {
				fmt.Fprintln(os.Stderr, err)
				os.Exit(1)
			}
			return
		}
	}
}
