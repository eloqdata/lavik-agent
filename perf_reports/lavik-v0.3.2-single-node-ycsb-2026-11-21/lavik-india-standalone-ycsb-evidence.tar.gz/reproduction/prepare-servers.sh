#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
config=../ssh_config
scp -F "$config" scripts/manage-server.sh scripts/isolate-server.sh scripts/setup-peers.sh \
  scripts/prepare-current-storage.sh data:/opt/lavik-bench/
ssh -F "$config" data 'bash /opt/lavik-bench/setup-peers.sh'
