#!/usr/bin/env bash
set -euo pipefail
export DEBIAN_FRONTEND=noninteractive
sudo apt-get install -qy --no-install-recommends build-essential
cd /opt/lavik-bench
curl -fsSL --retry 2 --max-time 150 https://codeload.github.com/redis/redis/tar.gz/refs/tags/8.10.3 -o redis-8.10.3.tar.gz
echo "85ae62e175cc76f638015fa18cb384b549b6808a765425d9e9d47466f69532ea  redis-8.10.3.tar.gz" | sha256sum -c
tar -xzf redis-8.10.3.tar.gz
make -C redis-8.10.3 -j8 REDIS_CFLAGS='' OPTIMIZATION=-O2 redis-server > /opt/lavik-bench/redis-build.log 2>&1
curl -fsSLO --retry 2 --max-time 150 https://github.com/dragonflydb/dragonfly/releases/download/v2.1/dragonfly-x86_64.tar.gz
echo "99c4abdfb0f08de9b228e6bea943ba549e7432ac58386279d6ae08b845f31ae5  dragonfly-x86_64.tar.gz" | sha256sum -c
tar -xzf dragonfly-x86_64.tar.gz
redis-8.10.3/src/redis-server --version
./dragonfly-x86_64 --version
