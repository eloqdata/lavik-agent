#!/usr/bin/env bash
set -euo pipefail
test "$(hostname -s)" = bench-india-client
product=$1
records=$2
from=$3
export YCSB_SWEEP_FULL_WINDOW=${4:-0}
case "$product/$records/$from" in
  redis/80000000/0|dragonfly/80000000/0|lavik/80000000/0)
    stages=(10000000 50000000 80000000) ;;
  lavik/1000000000/80000000)
    stages=(250000000 500000000 750000000 1000000000) ;;
  redis/80000000/80000000|dragonfly/80000000/80000000|lavik/80000000/80000000|lavik/1000000000/1000000000)
    stages=() ;;
  *) exit 2 ;;
esac
root=/opt/lavik-bench
server=10.87.0.21
output="$root/results-standalone/$product/$records"
mkdir -p "$output"
cd "$root"
printf '%s %s dataset target %s from %s\n' "$(date -u +%FT%TZ)" "$product" "$records" "$from"
redis-cli -h "$server" INFO server > "$output/server-version.txt"
python3 "$root/tcp-probe.py" "$server" 6379 | tee "$output/idle-ping.json"
if [[ $product = lavik && $from != "$records" ]]; then
  curl -fsS --max-time 10 "http://$server:9100/metrics" > "$output/metrics-before-load.prom"
fi
for to in "${stages[@]}"; do
  [[ $(timeout 8 redis-cli -h "$server" DBSIZE) = "$from" ]]
  log="$output/load-$from-$to.log"
  "$root/bulk-hash-load" -address "$server:6379" -start "$from" -end "$to" \
    -connections 64 -pipeline 32 2>&1 | tee "$log"
  grep -q "^final start=$from end=$to .* ack=$((to-from)) " "$log"
  [[ $(timeout 8 redis-cli -h "$server" DBSIZE) = "$to" ]]
  redis-cli -h "$server" INFO memory > "$output/memory-after-load-$to.txt"
  from=$to
done
"$root/probe-venv/bin/python" "$root/verify-standalone.py" "$output/pre-test.json" "$records"
if [[ $product = lavik ]]; then
  curl -fsS --max-time 10 "http://$server:9100/metrics" > "$output/metrics-before-test.prom"
fi
bash "$root/ycsb-standalone.sh" "$product" "$server" steady "$records"
"$root/probe-venv/bin/python" "$root/verify-standalone.py" "$output/post-test.json" "$records"
redis-cli -h "$server" INFO persistence > "$output/persistence.txt"
redis-cli -h "$server" INFO stats > "$output/stats.txt"
if [[ $product = lavik ]]; then
  curl -fsS --max-time 10 "http://$server:9100/metrics" > "$output/metrics.prom"
fi
if [[ $product = redis || $product = dragonfly ]]; then
  if grep -q '^evicted_keys:' "$output/stats.txt"; then
    grep -Fxq 'evicted_keys:0' <(tr -d '\r' < "$output/stats.txt")
  fi
fi
touch "$output/complete"
