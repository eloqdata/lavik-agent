#!/usr/bin/env bash
set -euo pipefail
test "$(hostname -s)" = bench-data-india
if systemctl is-active --quiet lavik-bench-v4-old; then
  printf '%s\n' 'Stop the old benchmark before allocating its adjacent storage.' >&2
  exit 1
fi
array=/dev/md/lavikbench
part=/dev/md/lavikbench3
evidence=/opt/lavik-bench/v4-repro/evidence
test -b "$array"
test "$(sudo blockdev --getss "$array")" = 512
sudo mdadm --detail "$array" > "$evidence/current-raid.txt"
test "$(awk '/Active Devices/{print $NF}' "$evidence/current-raid.txt")" = 6
test "$(awk '/Raid Level/{print $NF}' "$evidence/current-raid.txt")" = raid0
if [[ ! -b $part ]]; then
  sudo sfdisk --json "$array" > "$evidence/current-partitions-before.json"
  python3 - "$evidence/current-partitions-before.json" <<'PY' > "$evidence/current-partition.sfdisk"
import json
from pathlib import Path
import sys
table = json.loads(Path(sys.argv[1]).read_text())["partitiontable"]
parts = table["partitions"]
assert table["label"] == "gpt"
assert [part["name"] for part in parts] == ["lavik-v4-ycsb", "reserved-v4-ycsb"]
start = parts[-1]["start"] + parts[-1]["size"]
alignment = 24 * 2**20 // 512
start = ((start + alignment - 1) // alignment) * alignment
size = 6 * 2**40 // 512
assert start + size <= table["lastlba"]
print(f'start={start},size={size},type=linux,name="lavik-v032-standalone"')
PY
  sudo sfdisk --append "$array" < "$evidence/current-partition.sfdisk"
  sudo udevadm settle
fi
test "$(lsblk -dn -o PARTLABEL "$part" | xargs)" = lavik-v032-standalone
test "$(sudo blockdev --getsize64 "$part")" = 6597069766656
sudo sfdisk --json "$array" > "$evidence/current-partitions.json"
sudo wipefs --no-act --noheadings --output TYPE "$part" > "$evidence/current-signatures.txt"
test ! -s "$evidence/current-signatures.txt"
