from datetime import datetime, timezone
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys

base = Path("/opt/lavik-bench")
product, primary, records = sys.argv[1:4]
sweep = base / "results-standalone" / product / records / "sweep"
sweep.mkdir(parents=True, exist_ok=True)
status_tail = re.compile(r"\[(READ|UPDATE): .*?99\.9=([\d.]+)")
full_window_recheck = os.environ.get("YCSB_SWEEP_FULL_WINDOW") == "1"
candidates = ((48, 64, 80, 96) if full_window_recheck else
              (64, 96, 128, 200, 256, 300, 400, 512, 600, 800, 1024))
scouts = []
confirmations = []

def write_summary(**extra):
    result = {
        "time_utc": datetime.now(timezone.utc).isoformat(),
        "scout_windows": scouts, "confirmation_windows": confirmations, **extra,
    }
    path = sweep / "summary.json"
    staging = path.with_suffix(".tmp")
    staging.write_text(json.dumps(result, indent=2) + "\n")
    staging.replace(path)
    print(json.dumps(extra), flush=True)

def run_window(connections, label, seconds, reference=None):
    dirname = sweep / label
    dirname.mkdir(exist_ok=True)
    result = {"connections": connections, "window": label, "seconds": seconds}
    metrics = {}
    storm = 0
    guarded = False
    process = subprocess.Popen(
        ["bash", str(base / "ycsb-standalone.sh"), product, primary, "window", records, "0",
         str(connections), label, str(seconds)],
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, start_new_session=True,
    )
    with (dirname / "ycsb.log").open("w", buffering=1) as output:
        for line in process.stdout:
            output.write(line)
            if line.startswith("[") and "], " in line:
                try:
                    batch, name, value = line.rstrip().split(", ", 2)
                    metrics[batch.strip("[]"), name] = float(value)
                except ValueError:
                    pass
            if (reference or full_window_recheck) and " current ops/sec" in line:
                samples = {name.lower(): float(value) for name, value in status_tail.findall(line)}
                sustained_spike = any(
                    value > (20_000 if full_window_recheck else
                             max(3 * reference[f"{name}_p999_us"],
                                 reference[f"{name}_p999_us"] + 2000))
                    for name, value in samples.items()
                )
                storm = storm + 1 if sustained_spike else 0
                if storm >= 2 and not guarded:
                    guarded = True
                    # Interrupt the shell and Java together to cap the exploratory load.
                    try:
                        os.killpg(process.pid, signal.SIGTERM)
                    except ProcessLookupError:
                        pass
    code = process.wait()
    result["guard_stopped"] = guarded
    result["exit_code"] = code
    result["qps"] = metrics.get(("OVERALL", "Throughput(ops/sec)"))
    result["runtime_ms"] = metrics.get(("OVERALL", "RunTime(ms)"))
    for operation in ("read", "update"):
        tag = operation.upper()
        result[f"{operation}_p999_us"] = metrics.get((tag, "99.9PercentileLatency(us)"))
        result[f"{operation}_ok"] = int(metrics.get((tag, "Return=OK"), 0))
        result[f"{operation}_operations"] = int(metrics.get((tag, "Operations"), 0))
    valid_metrics = all(result[key] is not None for key in
                        ("qps", "runtime_ms", "read_p999_us", "update_p999_us"))
    counts_match = all(
        result[f"{op}_ok"] == result[f"{op}_operations"] > 0 for op in ("read", "update")
    )
    errors = any(tag in ("READ", "UPDATE") and metric.startswith("Return=")
                 and metric != "Return=OK" and value > 0
                 for (tag, metric), value in metrics.items())
    observed_ops = result["read_operations"] + result["update_operations"]
    operation_mix = result["update_operations"] / observed_ops if observed_ops else 0
    duration_ok = valid_metrics and (seconds * 1000 <= result["runtime_ms"] < (seconds + 3) * 1000)
    qps_ok = duration_ok and abs(result["qps"] - observed_ops * 1000 / result["runtime_ms"]) < 2
    result["valid"] = code == 0 and not guarded and counts_match and not errors and qps_ok and 0.049 <= operation_mix <= 0.051
    return result

def materially_worse(point, previous, multiplier, minimum_difference):
    return any(
        point[f"{op}_p999_us"] > multiplier * previous[f"{op}_p999_us"]
        and point[f"{op}_p999_us"] - previous[f"{op}_p999_us"] >= minimum_difference
        for op in ("read", "update")
    )

accepted = []
plateau = 0
stop_reason = "tested all configured connection levels"
for connections in candidates:
    reference = accepted[-1] if accepted else None
    warm = run_window(connections, f"{connections}-warm", 20, reference)
    if not warm["valid"]:
        scouts.append(warm)
        stop_reason = "error or sustained tail latency spike during warmup"
        break
    point = run_window(connections, f"{connections}-scout", 40, reference)
    scouts.append(point)
    write_summary(current_connections=connections)
    if not point["valid"]:
        stop_reason = "error or sustained tail latency spike during measurement"
        break
    if reference:
        gain = point["qps"] / reference["qps"] - 1
        if materially_worse(point, reference, 1.5, 750):
            stop_reason = "P99.9 rose at least 50% and 0.75 ms"
            break
        if gain < 0.07 and materially_worse(point, reference, 1.2, 250):
            stop_reason = "less than 7% throughput gain with a worse tail"
            break
        plateau = plateau + 1 if gain < 0.03 else 0
        if plateau >= 2:
            stop_reason = "two consecutive steps added less than 3% throughput each"
            break
    accepted.append(point)

if not accepted:
    write_summary(status="no valid scout", stop_reason=stop_reason)
    sys.exit(3)

best = max(point["qps"] for point in accepted)
shortlist = [point for point in accepted if point["qps"] >= best * 0.95]
choice = min(shortlist, key=lambda p: (max(p["read_p999_us"], p["update_p999_us"]),
                                        p["connections"]))
order = [choice] + [p for p in sorted(accepted, key=lambda p: p["connections"], reverse=True)
                    if p["connections"] < choice["connections"]]
for choice in order:
    connections = choice["connections"]
    write_summary(status="confirming", selected_scout=choice, stop_reason=stop_reason)
    warmup = run_window(connections, f"{connections}-confirm-warm", 30, choice)
    if not warmup["valid"]:
        confirmations.append(warmup)
        continue
    rounds = [run_window(connections, f"{connections}-confirm-{i}", 60, choice)
              for i in range(1, 4)]
    confirmations.extend(rounds)
    valid_rounds = all(p["valid"] for p in rounds)
    if valid_rounds and (full_window_recheck or sum(
        materially_worse(p, choice, 1.5, 750) for p in rounds
    ) < 2):
        def mean(key):
            return sum(p[key] for p in rounds) / len(rounds)
        write_summary(
            status="confirmed", selected_connections=connections, selected_scout=choice,
            stop_reason=stop_reason, qps=mean("qps"), read_p999_us=mean("read_p999_us"),
            update_p999_us=mean("update_p999_us"),
        )
        break
else:
    write_summary(status="no stable confirmation", stop_reason=stop_reason)
    sys.exit(4)
