# 单机 Hash YCSB 基准测试

在 Azure Central India 的同一台 16 vCPU 数据机上，Redis、Dragonfly 和 Lavik 各测试了 8,000 万条 Hash 记录。YCSB 在独立机器上发请求，统一使用 256 个连接。Lavik 随后扩容到 10 亿条，仍用一台数据机服务。

| 数据库 | Hash 记录数 | 连接数 | 吞吐量（ops/s） | 读 P99.9（ms） | 写 P99.9（ms） | 测后数据库报告内存（GiB） |
|---|---:|---:|---:|---:|---:|---:|
| Redis 8.10.3 | 80,000,000 | 256 | 385,755 | 2.553 | 2.627 | 100.2 |
| Dragonfly v2.1 | 80,000,000 | 256 | 537,054 | 12.655 | 13.076 | 101.5 |
| Lavik v0.3.2 | 80,000,000 | 256 | 631,666 | 2.565 | 2.063 | 6.3 |
| Lavik v0.3.2 | 1,000,000,000 | 256 | 621,528 | 2.610 | 2.132 | 55.7 |

8,000 万条数据集的字段值合计 **81.92 GB**。

Lavik 的数据量放大 12.5 倍后，达到 **621,528 ops/s**，为 8,000 万条测试吞吐的 **98.4%**。10 亿条的字段值合计 **1.024 TB**（十进制，1 TB = 10¹² B）。

10 亿条灌入后、正式压测前，Lavik 报告的可供前台写入空间较空库减少 **1.305 TB**。该值来自相同分区上两次 `lavik_storage_available_bytes` 的差值，包含引擎空间开销。此时引擎报告待持久化活动及脏暂存字节均为零。灌入全部 10 亿条的各阶段加总用时 **17.0 分钟**。

## 环境与操作口径

- 机房为 Azure Central India Zone 3。数据机为 `Standard_L16aos_v4`，16 vCPU、128 GiB 标称内存、AMD EPYC 9V74。独立 YCSB 发压机为 `Standard_F16als_v6`，16 vCPU。两台机器均开启加速网络。数据机 14 个 CPU 分配给服务，其余两个分配给系统和网卡中断。 [Azure L16aos_v4 规格](https://learn.microsoft.com/en-us/azure/virtual-machines/sizes/storage-optimized/laosv4-series)
- 每个 Hash 有 8 个 128 B 字段。每轮访问范围为当轮完整数据集，均匀随机。95% 请求读取整个 Hash，5% 请求更新全部 8 个字段。Redis 和 Dragonfly 用 YCSB Redis binding，设置 `redis.scanindex=none`（`HGETALL` / `HMSET`），Lavik 用专用 binding（`HGETALL` / `LAVIK.HREPLACE`）。正式发压每线程一个连接，每连接串行发请求。灌数单独采用 64 连接、每批 32 请求的流水线。 [YCSB 源码](https://github.com/eloqdata/YCSB/commit/247a2d448ebceff11a570a622c49ece161a27ed3)
- 每次只运行一个数据库实例。Redis 和 Dragonfly 为纯内存，设 112 GiB 内存限制，关闭定期快照、淘汰及 Redis AOF。Lavik 使用 io_uring 和本地六盘 NVMe RAID0 的裸分区，内存上限设为 96 GiB。内存列沿用各引擎的 `INFO MEMORY used_memory` 定义，统计口径可能不同。 [Redis 8.10.3](https://github.com/redis/redis/releases/tag/8.10.3) · [Dragonfly v2.1](https://github.com/dragonflydb/dragonfly/releases/tag/v2.1) · [Lavik v0.3.2](https://github.com/eloqdata/lavik/releases/tag/v0.3.2)
- 正式窗口固定 256 连接，三轮各 60 秒。表中是三轮吞吐及各轮读写 P99.9 的算术平均。每组测试前后验证键数、独立服务状态，并抽查 1,003 条记录的字段名与字段长度。正式窗口的读写都返回成功。三款数据库初次装载的样本摘要一致。取样和容量证明见随报告附带的原始证据。

## 三轮正式结果

| 数据库 | 记录数 | 轮次 | 吞吐量（ops/s） | 读 P99.9（ms） | 写 P99.9（ms） |
|---|---|---:|---:|---:|---:|
| Redis 8.10.3 | 8,000 万条 | 1 | 337,159 | 2.607 | 2.711 |
| Redis 8.10.3 | 8,000 万条 | 2 | 410,254 | 2.547 | 2.617 |
| Redis 8.10.3 | 8,000 万条 | 3 | 409,853 | 2.505 | 2.553 |
| Dragonfly v2.1 | 8,000 万条 | 1 | 540,583 | 9.839 | 10.223 |
| Dragonfly v2.1 | 8,000 万条 | 2 | 537,099 | 13.407 | 13.855 |
| Dragonfly v2.1 | 8,000 万条 | 3 | 533,482 | 14.719 | 15.151 |
| Lavik v0.3.2 | 8,000 万条 | 1 | 627,763 | 2.647 | 2.077 |
| Lavik v0.3.2 | 8,000 万条 | 2 | 634,695 | 2.557 | 2.055 |
| Lavik v0.3.2 | 8,000 万条 | 3 | 632,541 | 2.491 | 2.057 |
| Lavik v0.3.2 | 10 亿条 | 1 | 629,384 | 2.559 | 2.019 |
| Lavik v0.3.2 | 10 亿条 | 2 | 623,499 | 2.739 | 2.211 |
| Lavik v0.3.2 | 10 亿条 | 3 | 611,701 | 2.531 | 2.165 |

## 原始证据

同行的证据压缩包包含版本、机器与存储信息，灌数阶段日志、抽样校验、各窗口的 YCSB 日志与 HdrHistogram、Lavik 存储指标和复现实验脚本。此前的连接数探索试验单独留档。
