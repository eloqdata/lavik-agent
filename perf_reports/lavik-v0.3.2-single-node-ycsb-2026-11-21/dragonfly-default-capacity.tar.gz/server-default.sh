#!/usr/bin/env bash
set -euo pipefail
test "$(hostname -s)" = bench-data-india
action=$1
name=$2
root=/opt/lavik-bench
ip=10.87.0.21
case "$name" in lavik|redis|dragonfly) ;; *) exit 2 ;; esac
unit="india-single-$name"
if [[ $action = stop ]]; then
  if [[ $name = dragonfly ]] && systemctl is-active --quiet "$unit"; then
    redis-cli -h "$ip" SHUTDOWN NOSAVE || true
    for attempt in {1..30}; do
      if ! systemctl is-active --quiet "$unit"; then exit 0; fi
      sleep 1
    done
  fi
  sudo systemctl stop "$unit"
  exit
fi
[[ $action = start ]]
for service in lavik-bench-v4-old india-single-lavik india-single-redis india-single-dragonfly; do
  if systemctl is-active --quiet "$service"; then
    printf 'Service already serving: %s\n' "$service" >&2
    exit 1
  fi
done
identity=(--uid=bench --gid=bench)
memory_limit=112gb
case "$name" in
  redis)
    args=("$root/redis-8.10.3/src/redis-server" --bind "$ip" --protected-mode no --save "" --appendonly no
      --maxmemory "$memory_limit" --maxmemory-policy noeviction
      --hash-max-listpack-value 256 --hash-max-listpack-entries 512 --io-threads 14 --port 6379)
    ;;
  dragonfly)
    args=("$root/dragonfly-x86_64" "--bind=$ip" --port=6379
      "--maxmemory=$memory_limit" --proactor_threads=14 --snapshot_cron= --cache_mode=false
      )
    ;;
  lavik)
    identity=()
    part=/dev/md/lavikbench3
    test "$(lsblk -dn -o PARTLABEL "$part" | xargs)" = lavik-v032-standalone
    args=("$root/lavik-v0.3.2-linux-x86_64/lavik" --storage=uring --network=kernel
      --bind "$ip" --port 6379 --metrics-port 9100 --threads 14 --pin-workers --max-memory 96gb
      --shutdown-checkpoint --data-file "$part" --log-dir "/var/lib/lavik-bench/india-single-lavik")
    ;;
esac
state=/var/lib/lavik-bench/"$unit"
sudo install -d -m 0700 -o bench -g bench "$state"
sudo systemd-run --unit="$unit" --collect --slice=india-benchmark.slice "${identity[@]}" \
  -p AllowedCPUs=0-13 -p CPUAffinity=0-13 -p LimitNOFILE=65535 -p LimitMEMLOCK=infinity \
  -p TimeoutStopSec=900 -p MemorySwapMax=0 -p "WorkingDirectory=$state" "${args[@]}"
