set -eu
cd /opt/lavik-bench
host=10.87.0.21
prev=0
out=/tmp/df-capacity-confirm
mkdir "$out"
for n in 73000000; do
  mkdir "$out/$n"
  q="$out/$n"
  if ! ./bulk-hash-load -address "$host:6379" -start "$prev" -end "$n" -connections 64 -pipeline 32 > "$q/load.log" 2>&1; then
    redis-cli -h "$host" DBSIZE > "$q/partial.txt"
    redis-cli -h "$host" INFO memory > "$q/memory.txt"
    tail -3 "$q/load.log"; cat "$q/partial.txt"; break
  fi
  probe-venv/bin/python verify-standalone.py "$q/pre.json" "$n"
  redis-cli -h "$host" DEBUG OBJECT "$(redis-cli -h "$host" RANDOMKEY)" > "$q/encoding.txt"
  if [[ $n == 73000000 ]]; then
    res="results-standalone/dragonfly/$n"
    test ! -e "$res"
    sudo install -d -o bench -g bench "$res"
    bash ycsb-standalone.sh dragonfly "$host" steady "$n"
    cp -r "$res/sweep" "$q/"
    probe-venv/bin/python verify-standalone.py "$q/post.json" "$n"
    redis-cli -h "$host" INFO stats > "$q/stats.txt"
  fi
  prev=$n
done
