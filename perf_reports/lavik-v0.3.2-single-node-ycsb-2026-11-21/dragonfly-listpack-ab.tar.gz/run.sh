set -euo pipefail
cd "$(dirname "$0")"
d(){ ssh -F ../ssh_config data "$@"; }
c(){ ssh -F ../ssh_config client "$@"; }
base=/opt/lavik-bench
res=$base/results-standalone/dragonfly/40000000
c "test ! -e $res"
test "$(c 'redis-cli -h 10.87.0.21 DBSIZE')" = 1000000000
d "bash $base/manage-server.sh stop lavik"
restore(){ d "if systemctl is-active --quiet india-single-dragonfly; then bash $base/manage-server.sh stop dragonfly; fi; if ! systemctl is-active --quiet india-single-lavik; then bash $base/manage-server.sh start lavik; fi"; }
trap restore EXIT
for mode in default tuned; do
  scp -F ../ssh_config server-$mode.sh data:/tmp/listpack-$mode.sh
  d "bash /tmp/listpack-$mode.sh start dragonfly"
  c "set -e; cd $base; sudo install -d -o bench -g bench $res; for i in {1..30}; do redis-cli -h 10.87.0.21 PING 2>/dev/null | grep -q PONG && break; sleep 1; done; test \$(redis-cli -h 10.87.0.21 DBSIZE) = 0; ./bulk-hash-load -address 10.87.0.21:6379 -start 0 -end 40000000 -connections 64 -pipeline 32 > $res/load.log; probe-venv/bin/python verify-standalone.py $res/pre.json 40000000; redis-cli -h 10.87.0.21 OBJECT ENCODING \$(redis-cli -h 10.87.0.21 RANDOMKEY) > $res/encoding.txt; bash ycsb-standalone.sh dragonfly 10.87.0.21 steady 40000000; probe-venv/bin/python verify-standalone.py $res/post.json 40000000; redis-cli -h 10.87.0.21 INFO stats > $res/stats.txt"
  mkdir "$mode"
  c "tar -czf - -C $res ." | tar -xzf - -C "$mode"
  c "sudo mv $res $res-listpack-$mode"
  d "bash $base/manage-server.sh stop dragonfly"
done
