set -euo pipefail
test "$(hostname -s)" = bench-data-india
root=/opt/lavik-bench
sudo systemctl stop india-redis-default-ycsb
state=/var/lib/lavik-bench/redis-default-ycsb
sudo install -d -m 0700 -o bench -g bench "$state"
sudo systemd-run --unit=india-redis-default-ycsb --collect --slice=india-benchmark.slice --uid=bench --gid=bench -p AllowedCPUs=0-13 -p CPUAffinity=0-13 -p LimitNOFILE=65535 -p MemorySwapMax=0 -p "WorkingDirectory=$state" "$root/redis-8.10.3/src/redis-server" --bind 10.87.0.21 --protected-mode no --save "" --maxmemory 112gb --io-threads 14
for i in {1..30}; do if redis-cli -h 10.87.0.21 PING | grep -qx PONG; then break; fi; sleep 1; done
redis-cli -h 10.87.0.21 CONFIG GET hash-max-listpack-value hash-max-listpack-entries maxmemory io-threads
