set -euo pipefail
root=/opt/lavik-bench
cd "$root"
out=$root/results-redis-default-v032
mkdir -p "$out"
test ! -f "$out/pre.json"
sed 's|results-standalone|results-redis-default-v032|g;s|"$base/ycsb-fixed.py"|"$base/ycsb-fixed-default.py"|' ycsb-standalone.sh > ycsb-redis-default.sh
sed 's|results-standalone|results-redis-default-v032|g;s|"ycsb-standalone.sh"|"ycsb-redis-default.sh"|' ycsb-fixed.py > ycsb-fixed-default.py
host=10.87.0.21
r=(redis-cli -h "$host" --raw)
test "$("${r[@]}" CONFIG GET hash-max-listpack-value | tail -1)" = 64
test "$("${r[@]}" CONFIG GET hash-max-listpack-entries | tail -1)" = 512
test "$("${r[@]}" DBSIZE)" = 0
"${r[@]}" INFO server > "$out/version.txt"
"${r[@]}" CONFIG GET hash-max-listpack-value hash-max-listpack-entries maxmemory io-threads > "$out/config.txt"
prev=0
for n in 40000000 50000000 60000000 65000000 70000000 75000000 80000000; do
 if ((prev)); then
   used=$("${r[@]}" INFO memory | sed -n 's/^used_memory:\([0-9]*\).*/\1/p')
   if (( used*n/prev > 112*1024*1024*1024*98/100 )); then break; fi
 fi
 ./bulk-hash-load -address "$host:6379" -start "$prev" -end "$n" -connections 64 -pipeline 32 > "$out/load-$n.log" 2>&1
 test "$("${r[@]}" DBSIZE)" = "$n"
 "${r[@]}" INFO memory > "$out/memory-$n.txt"
 prev=$n
done
n=$prev
"${r[@]}" OBJECT ENCODING "$("${r[@]}" RANDOMKEY)" > "$out/encoding.txt"
probe-venv/bin/python verify-standalone.py "$out/pre.json" "$n"
bash ycsb-redis-default.sh redis "$host" steady "$n"
probe-venv/bin/python verify-standalone.py "$out/post.json" "$n"
"${r[@]}" INFO stats > "$out/stats.txt"
touch "$out/complete"
