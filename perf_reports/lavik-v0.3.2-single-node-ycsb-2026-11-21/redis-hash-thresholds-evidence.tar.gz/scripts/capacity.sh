set -euo pipefail
cd /opt/lavik-bench
out=$PWD/results-redis-default-v032
test -f "$out/complete"
n=$(python3 -c 'import json; print(json.load(open("results-redis-default-v032/post.json"))["records"])')
r=(redis-cli -h 10.87.0.21 --raw)
test "$("${r[@]}" DBSIZE)" = "$n"
if (( n < 80000000 )); then
  set +e
  ./bulk-hash-load -address 10.87.0.21:6379 -start "$n" -end 80000000 -connections 64 -pipeline 32 > "$out/capacity-80m.log" 2>&1
  rc=$?
  set -e
  if ((rc)); then grep -i 'OOM' "$out/capacity-80m.log" > "$out/oom.txt"; fi
fi
"${r[@]}" DBSIZE > "$out/capacity-count.txt"
"${r[@]}" INFO memory > "$out/capacity-memory.txt"
"${r[@]}" INFO stats > "$out/capacity-stats.txt"
