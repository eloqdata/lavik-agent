set -euo pipefail
cd /opt/lavik-bench
out=$PWD/results-redis-matched-v032
mkdir "$out"
n=$(python3 -c 'import json; print(json.load(open("results-redis-default-v032/post.json"))["records"])')
r=(redis-cli -h 10.87.0.21 --raw)
test "$("${r[@]}" DBSIZE)" = 0
test "$("${r[@]}" CONFIG GET hash-max-listpack-value | tail -1)" = 256
"${r[@]}" CONFIG GET hash-max-listpack-value hash-max-listpack-entries maxmemory io-threads > "$out/config.txt"
sed 's|results-redis-default-v032|results-redis-matched-v032|g;s|ycsb-fixed-default.py|ycsb-fixed-matched.py|g' ycsb-redis-default.sh > ycsb-redis-matched.sh
sed 's|results-redis-default-v032|results-redis-matched-v032|g;s|ycsb-redis-default.sh|ycsb-redis-matched.sh|g' ycsb-fixed-default.py > ycsb-fixed-matched.py
./bulk-hash-load -address 10.87.0.21:6379 -start 0 -end "$n" -connections 64 -pipeline 32 > "$out/load.log" 2>&1
"${r[@]}" OBJECT ENCODING "$("${r[@]}" RANDOMKEY)" > "$out/encoding.txt"
probe-venv/bin/python verify-standalone.py "$out/pre.json" "$n"
bash ycsb-redis-matched.sh redis 10.87.0.21 steady "$n"
probe-venv/bin/python verify-standalone.py "$out/post.json" "$n"
"${r[@]}" INFO stats > "$out/stats.txt"
touch "$out/complete"
