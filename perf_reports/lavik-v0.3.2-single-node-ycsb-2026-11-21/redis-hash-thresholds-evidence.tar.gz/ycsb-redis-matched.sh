#!/usr/bin/env bash
set -euo pipefail
product=$1
primary=$2
phase=$3
records=${4:-10000000}
first_record=${5:-0}
workers=${6:-128}
case "$product" in lavik|redis|dragonfly) ;; *) exit 2 ;; esac
case "$phase" in load|steady|window) ;; *) exit 2 ;; esac
binding=redis
[[ "$product" != lavik ]] || binding=lavik
base=/opt/lavik-bench
root="$base/YCSB-247a2d448ebceff11a570a622c49ece161a27ed3"
dest="$base/results-redis-matched-v032/$product/$records"
mkdir -p "$dest"
if [[ "$phase" == steady ]]; then
  exec python3 "$base/ycsb-fixed-matched.py" "$product" "$primary" "$records"
fi
cd "$root"
common=(-P workloads/workloadb -threads "$workers" -p recordcount="$records"
  -p fieldcount=8 -p fieldlength=128 -p readallfields=true -p writeallfields=true
  -p fieldlengthdistribution=constant -p requestdistribution=uniform
  -p readproportion=0.95 -p updateproportion=0.05 -p scanproportion=0
  -p insertproportion=0 -p readmodifywriteproportion=0
  -p "$binding.host=$primary" -p "$binding.port=6379" -p "$binding.timeout=2000")
if [[ "$binding" == redis ]]; then
  common+=(-p redis.scanindex=none)
fi
if [[ "$phase" == load ]]; then
  test "$first_record" -ge 0
  test "$first_record" -lt "$records"
  count=$((records-first_record))
  bin/ycsb.sh load "$binding" -s "${common[@]}" \
    -p insertstart="$first_record" -p insertcount="$count" 2>&1 | tee "$dest/load.log"
elif [[ "$phase" == window ]]; then
  name=$7
  seconds=$8
  case "$name" in
    *[!a-z0-9-]*|'') exit 2 ;;
  esac
  output="$dest/sweep/$name"
  mkdir -p "$output"
  exec bin/ycsb.sh run "$binding" -s "${common[@]}" -p operationcount=2000000000 \
    -p maxexecutiontime="$seconds" -p status.interval=5 \
    -p hdrhistogram.percentiles=50,95,99,99.9 -p hdrhistogram.fileoutput=true \
    -p "hdrhistogram.output.path=$output/"
fi
